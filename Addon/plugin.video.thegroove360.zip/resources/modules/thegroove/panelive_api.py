from resources.modules.httpclient import HttpClient
import re
import string
import sys


class PanelApi:

    def __init__(self, url, **kwargs):
        self.url = url
        self.api_url = self.url.replace("/get.php?", "/player_api.php?")
        self.__dict__.update(**kwargs)
        self.types = ["Live"]

    def root(self):
        ret = []
        for st in self.types:
            ret.append((st, self.url))
        return ret

    def get_live_categories(self, ids_category=None):
        url = self.api_url + "&action=get_live_categories"
        req = HttpClient().get_request(url)
        res = req.json()

        ret = []
        for r in res:
            if ids_category and int(r["category_id"]) not in ids_category:
                continue

            cname = filter(lambda x: x in string.printable, r["category_name"])
            if sys.version_info[0] > 2:
                cname = ''.join(list(cname))

            ret.append((self.api_url + "&action=get_live_streams&category_id=" + r["category_id"], cname))

        return ret

    def get_live_category_channels(self, url="", category_id=""):
        if category_id != "":
            url = self.api_url + "&action=get_live_streams&category_id=" + category_id

        ret = []
        req = HttpClient().get_request(url)
        res = req.json()

        regex = r'(http.*?://.*?(?:(?::[\d]+)|)/).*?\?.*?username=([^&]+).*?password=([^&]+)'
        base_url, username, password = re.compile(regex, re.DOTALL).findall(url)[0]

        for r in res:
            cname = filter(lambda x: x in string.printable, r["name"])
            if sys.version_info[0] > 2:
                cname = ''.join(list(cname))
            rurl = base_url + "live/" + username + "/" + password + "/" + str(r["stream_id"]) + ".ts"
            ret.append((cname, rurl))

        return ret

