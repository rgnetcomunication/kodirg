import sys
l1l1lll_thegroove=sys.version_info[0]==2
l1l1l1l_thegroove=2048
l1111l_thegroove=7
def l11lll_thegroove(l11l1l_thegroove):
 global l1l1ll_thegroove
 l11_thegroove=ord(l11l1l_thegroove[-1])
 l1l1l_thegroove=l11l1l_thegroove[:-1]
 l11lll1_thegroove=l11_thegroove%len(l1l1l_thegroove)
 l1_thegroove=l1l1l_thegroove[:l11lll1_thegroove]+l1l1l_thegroove[l11lll1_thegroove:]
 if l1l1lll_thegroove:
  l1ll1ll_thegroove=l1l111l_thegroove().join([l1ll1l1_thegroove(ord(char)-l1l1l1l_thegroove-(l11l11_thegroove+l11_thegroove)%l1111l_thegroove)for l11l11_thegroove,char in enumerate(l1_thegroove)])
 else:
  l1ll1ll_thegroove=str().join([chr(ord(char)-l1l1l1l_thegroove-(l11l11_thegroove+l11_thegroove)%l1111l_thegroove)for l11l11_thegroove,char in enumerate(l1_thegroove)])
 return eval(l1ll1ll_thegroove)
import base64
import hashlib
import os
import sys
import random
l1l1111_thegroove=False
try:
 from Cryptodome.Cipher import AES
 import resources.lib.pyaes.aes as pyaes
except:
 import resources.lib.pyaes.aes as pyaes
 l1l1111_thegroove=True
import inspect
from datetime import datetime
try:
 from zoneinfo import ZoneInfo
except:
 from backports.zoneinfo import ZoneInfo
try:
 import xbmc
 import xbmcaddon
 import xbmcgui
 import xbmcvfs
except:
 pass
class Token:
 def __init__(self):
  self.name=l11lll_thegroove(u"ࠣࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡵࡪࡨ࡫ࡷࡵ࡯ࡷࡧ࠶࠺࠵ࠨ࣏")
  self.token=l11lll_thegroove(u"ࠤ࣐ࠥ")
  self.l1l1ll1_thegroove=l11lll_thegroove(u"ࠥ࠷࠸࠸ࡓࡆࡅࡕࡉ࡙ࡧࡢࡤ࠳࠵࠷࠹ࠨ࣑")
  self.l1lll1l_thegroove=l11lll_thegroove(u"࡙ࠦ࡮ࡥࡨࡴࡲࡳࡻ࡫ࠠ࠴࠸࠳࣒ࠦ")
  self.result=l11lll_thegroove(u"ࠧࠨ࣓")
  self.l1lll11_thegroove=0
  self.l1l1111_thegroove=l1l1111_thegroove
 def l1ll11_thegroove(self):
  __caller__=inspect.stack()[1].function
  self.l1ll_thegroove(__caller__)
  l1l11l11l_thegroove=l11lll_thegroove(u"ࠨࡅࡶࡴࡲࡴࡪ࠵ࡒࡰ࡯ࡨࠦࣔ")
  l11lllll1_thegroove=datetime.now(ZoneInfo(l1l11l11l_thegroove))
  l11llll1l_thegroove=datetime.timestamp(l11lllll1_thegroove)
  return int(l11llll1l_thegroove)
 def l1l_thegroove(self,l1l1l1_thegroove):
  __caller__=inspect.stack()[1].function
  self.l1ll_thegroove(__caller__)
  l11ll_thegroove=self.l1l111111_thegroove(l11lll_thegroove(u"ࠢࡪࡶࡨࡱࡤࡶࡡࡳࡵࡨࡶ࠳ࡶࡹࠣࣕ"))
  l111l_thegroove=len(open(l11ll_thegroove).read().splitlines())
  l1ll111_thegroove=l1l1l1_thegroove%l111l_thegroove
  self.l1lll11_thegroove=l1ll111_thegroove
  return l1ll111_thegroove
 def l1l111111_thegroove(self,name):
  try:
   __addon__=xbmcaddon.Addon(id=self.name)
   if sys.version_info[0]<3:
    cwd=xbmc.translatePath(__addon__.getAddonInfo(l11lll_thegroove(u"ࠨࡲࡤࡸ࡭࠭ࣖ")))
   else:
    cwd=xbmcvfs.translatePath(__addon__.getAddonInfo(l11lll_thegroove(u"ࠩࡳࡥࡹ࡮ࠧࣗ")))
  except:
   cwd=os.getcwd()+l11lll_thegroove(u"ࠥ࠳ࡹ࡫ࡳࡵࠤࣘ")
  path=(l11lll_thegroove(u"ࠦࡷ࡫ࡳࡰࡷࡵࡧࡪࡹࠬ࡮ࡱࡧࡹࡱ࡫ࡳ࠭ࠤࣙ")+name).split(l11lll_thegroove(u"ࠧ࠲ࠢࣚ"))
  l11ll_thegroove=cwd+os.sep+os.path.join(*path)
  return l11ll_thegroove
 @staticmethod
 def l111_thegroove(l11ll1l_thegroove,l1ll111_thegroove):
  try:
   with open(l11ll1l_thegroove,l11lll_thegroove(u"࠭ࡲࠨࣛ"))as f:
    for line_number,line in enumerate(f):
     if line_number==l1ll111_thegroove:
      return str(line).strip()
  except Exception as e:
   pass
 def set_token(self):
  if not self.l1l111_thegroove():
   return None
  try:
   l1l1l1_thegroove=self.l1ll11_thegroove()
   line=self.l1l_thegroove(l1l1l1_thegroove)
   l1l1111l1_thegroove=str(len(str(line)))+str(line)
   n=(6-len(l1l1111l1_thegroove))
   l1l11l111_thegroove=pow(10,n-1)
   l1l1111ll_thegroove=pow(10,n)-1
   r=random.randint(l1l11l111_thegroove,l1l1111ll_thegroove)
   token=str(l1l1l1_thegroove)+l11lll_thegroove(u"ࠢ࠯ࠤࣜ")+l1l1111l1_thegroove+str(r)
   self.token=base64.urlsafe_b64encode(token.encode(l11lll_thegroove(u"ࠣࡷࡷࡪ࠲࠾ࠢࣝ"))).decode()
   return line
  except Exception as e:
   import traceback
   traceback.print_stack()
   print(e)
   self.l11l1_thegroove(l11lll_thegroove(u"ࠤࡉࡳࡷࡨࡩࡥࡦࡨࡲࠧࣞ"))
 def set_result(self,data):
  if not self.l1l111_thegroove():
   return None
  if data.headers and data.headers[l11lll_thegroove(u"ࠥࡘ࡭࡫ࡧࡳࡱࡲࡺࡪࠨࣟ")]==self.token:
   self.result=self.l11l_thegroove(data.text,self.l1lll11_thegroove)
  else:
   self.l11l1_thegroove(l11lll_thegroove(u"ࠦࡋࡵࡲࡣ࡫ࡧࡨࡪࡴࠢ࣠"))
   return None
 def l1l1_thegroove(self,text):
  __caller__=inspect.stack()[1].function
  self.l1ll_thegroove(__caller__)
  return None
 def l11l_thegroove(self,data,l1lll11_thegroove):
  __caller__=inspect.stack()[1].function
  self.l1ll_thegroove(__caller__)
  try:
   l11ll_thegroove=self.l1l111111_thegroove(l11lll_thegroove(u"ࠧ࡯ࡴࡦ࡯ࡢࡴࡦࡸࡳࡦࡴ࠱ࡴࡾࠨ࣡"))
   l11llllll_thegroove=self.l111_thegroove(l11ll_thegroove,l1lll11_thegroove).rstrip().lstrip()
   if len(l11llllll_thegroove)<32:
    l11llllll_thegroove=l11llllll_thegroove.ljust(32,l11lll_thegroove(u"࠭ࠠࠨ࣢"))
   if len(l11llllll_thegroove)>32:
    l11llllll_thegroove=l11llllll_thegroove[0:32]
   l1l11111l_thegroove=str(hashlib.sha256(l11llllll_thegroove.encode(l11lll_thegroove(u"ࠢࡶࡶࡩ࠱࠽ࠨࣣ"))).hexdigest())
   l1lll1_thegroove=l1l11111l_thegroove[:16]
   if self.l1l1111_thegroove:
    aes=pyaes.AESModeOfOperationCFB(l11llllll_thegroove.encode(l11lll_thegroove(u"ࠣࡷࡷࡪ࠲࠾ࠢࣤ")),l1lll1_thegroove)
    result=aes.decrypt(base64.urlsafe_b64decode(data.encode(l11lll_thegroove(u"ࠤࡸࡸ࡫࠳࠸ࠣࣥ"))+l11lll_thegroove(u"ࠥࡁࡂࠨࣦ").encode(l11lll_thegroove(u"ࠦࡺࡺࡦ࠮࠺ࠥࣧ"))))
   else:
    l1l1l11_thegroove=AES.new(l11llllll_thegroove.encode(l11lll_thegroove(u"ࠧࡻࡴࡧ࠯࠻ࠦࣨ")),AES.MODE_CFB,l1lll1_thegroove.encode(l11lll_thegroove(u"ࠨࡵࡵࡨ࠰࠼ࣩࠧ")))
    result=l1l1l11_thegroove.decrypt(base64.urlsafe_b64decode(data.encode(l11lll_thegroove(u"ࠢࡶࡶࡩ࠱࠽ࠨ࣪"))+l11lll_thegroove(u"ࠣ࠿ࡀࠦ࣫").encode(l11lll_thegroove(u"ࠤࡸࡸ࡫࠳࠸ࠣ࣬"))))
   if str(l1lll11_thegroove)==str(self.l1lll11_thegroove):
    return result.decode(l11lll_thegroove(u"ࠥࡹࡹ࡬࠭࠹ࠤ࣭"))
   else:
    self.l11l1_thegroove(l11lll_thegroove(u"ࠦࡊࡸࡲࡰࡴࡨࠤ࠹࠶࠵࣮ࠣ"),l11lll_thegroove(u"ࠧࡏ࡭ࡱࡱࡶࡷ࡮ࡨࡩ࡭ࡧࠣࡇࡴࡳࡰ࡭ࡧࡷࡥࡷ࡫ࠠࡍࡣࠣࡖ࡮ࡩࡨࡪࡧࡶࡸࡦࠨ࣯"))
  except Exception as e:
   self.l11l1_thegroove(l11lll_thegroove(u"ࠨࡅࡳࡴࡲࡶࡪࠦ࠴࠱࠹ࣰࠥ"),l11lll_thegroove(u"ࠢࡊ࡯ࡳࡳࡸࡹࡩࡣ࡫࡯ࡩࠥࡉ࡯࡮ࡲ࡯ࡩࡹࡧࡲࡦࠢࡏࡥࠥࡘࡩࡤࡪ࡬ࡩࡸࡺࡡࣱࠣ"))
   import traceback
   traceback.print_stack()
   print(e)
  return None
 def l1l111_thegroove(self,skip=False):
  return True
  files=[l11lll_thegroove(u"ࠣࡶ࡫ࡩ࡬ࡸ࡯ࡰࡸࡨ࠰ࡹ࡮ࡥࡨࡴࡲࡳࡻ࡫࡟ࡩࡶࡷࡴࡨࡲࡩࡦࡰࡷ࠲ࡵࡿࣲࠢ"),l11lll_thegroove(u"ࠤ࡬ࡸࡪࡳ࡟ࡱࡣࡵࡷࡪࡸ࠮ࡱࡻࠥࣳ"),l11lll_thegroove(u"ࠥ࠲࠳࠲࡬ࡪࡤ࠯ࡴࡱࡻࡧࡪࡰ࠱ࡴࡾࠨࣴ")]
  l1l111l1l_thegroove=[l11lll_thegroove(u"ࠦࡦ࠹ࡢࡢ࠴࠶ࡩ࠼࠹ࡤ࠱࠺ࡤ࠺࡫ࡩࡥࡣࡧ࠹࠵࠸࠸࠳ࡤࡧ࠷࠹ࡦ࠻ࡥ࠸ࡨ࠹࠼ࡨ࡬࠸࠶࠸࠴࠶ࡩ࠸࠴࠶࠺࠸ࡪ࠾࠼࠵ࡣࡨࡥ࠸࠸ࡧ࠰࠱ࡥ࠵࠸ࡩࠨࣵ"),l11lll_thegroove(u"ࠧ࠾࠵࠱࠷࠵ࡨࡩ࡬࠱࠹࠳࠶࠹ࡧ࡫࠳࠳ࡤ࠳࠽ࡦࡩ࠸ࡦ࠵࠻࠼ࡨ࡫࠸࠺࠶࠸࠷࠺ࡨࡦ࠷࠻࠻ࡩ࠹ࡧ࠰࠷࠷࠴࠺ࡨ࡬࠱ࡢࡦࡥ࠼ࡪ࠺ࡣ࠳ࡥ࠸࠵ࡧ࡫ࣶࠢ"),l11lll_thegroove(u"ࠨ࠸ࡤࡣ࠶࠶࡫࠹࠲࠷ࡨ࠴࠶࠾࠹࠱࠵ࡨ࠷࠴࠽࡫ࡢ࠶࠸ࡧ࠼ࡧࡪࡢ࠱࠺࠶ࡪ࠼ࡩ࠲ࡦ࠷࠵ࡪ࠽࠶࠳࠱࠹࠶ࡩ࠹࠶ࡥ࠱ࡥ࠶࠺࠵࠶࠹࠳࠻ࡤ࠸࠷࠽ࡣࠣࣷ")]
  for k,l1l111ll1_thegroove in enumerate(files):
   l11ll_thegroove=self.l1l111111_thegroove(l1l111ll1_thegroove)
   try:
    with open(l11ll_thegroove,l11lll_thegroove(u"ࠢࡳࡤࠥࣸ"))as f:
     l1l111lll_thegroove=f.read()
     l1l111l11_thegroove=hashlib.sha256(l1l111lll_thegroove).hexdigest()
     if l1l111l11_thegroove!=l1l111l1l_thegroove[k]:
      print(l11ll_thegroove+l11lll_thegroove(u"ࠣ࠼ࣹࠣࠦ")+l1l111l11_thegroove+l11lll_thegroove(u"ࠤࠣࡁࡃࣺࠦࠢ")+l1l111l1l_thegroove[k])
      raise Exception
   except Exception as e:
    self.l11l1_thegroove(l11lll_thegroove(u"ࠥࡉࡷࡸ࡯ࡳࡧࠣ࠴ࠧࣻ"),l11lll_thegroove(u"ࠦࡋࡻ࡮ࡻ࡫ࡲࡲࡪࠦࡄࡪࡵࡳࡳࡳ࡯ࡢࡪ࡮ࡨࠤࡘࡵ࡬ࡰࠢࡖࡹࠧࣼ"),self.l1lll1l_thegroove+l11lll_thegroove(u"ࠧࠦࡁࡥࡦࡲࡲࠧࣽ"))
    return False
  if skip is False:
   __caller__=inspect.stack()[1].function
   self.l1ll_thegroove(__caller__)
  try:
   l1ll11l_thegroove=xbmc.getInfoLabel(l11lll_thegroove(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡓࡰࡺ࡭ࡩ࡯ࡐࡤࡱࡪ࠭ࣾ"))
   l1ll11l_thegroove=xbmcaddon.Addon(l1ll11l_thegroove).getAddonInfo(l11lll_thegroove(u"ࠧ࡯ࡣࡰࡩࠬࣿ"))
   if l1ll11l_thegroove!=self.l1lll1l_thegroove:
    raise Exception()
  except Exception as e:
   self.l11l1_thegroove(l11lll_thegroove(u"ࠣࡇࡵࡶࡴࡸࡥࠡ࠳ࠥऀ"),l11lll_thegroove(u"ࠤࡉࡹࡳࢀࡩࡰࡰࡨࠤࡉ࡯ࡳࡱࡱࡱ࡭ࡧ࡯࡬ࡦࠢࡖࡳࡱࡵࠠࡔࡷࠥँ"),self.l1lll1l_thegroove+l11lll_thegroove(u"ࠥࠤࡆࡪࡤࡰࡰࠥं"))
   return False
  try:
   l111ll_thegroove=xbmcaddon.Addon(id=self.name)
   xbmcvfs.translatePath(l111ll_thegroove.getAddonInfo(l11lll_thegroove(u"ࠫࡵࡧࡴࡩࠩः")))
  except:
   self.l11l1_thegroove(l11lll_thegroove(u"ࠧࡋࡲࡳࡱࡵࡩࠥ࠸ࠢऄ"),l11lll_thegroove(u"ࠨࡆࡶࡰࡽ࡭ࡴࡴࡥࠡࡆ࡬ࡷࡵࡵ࡮ࡪࡤ࡬ࡰࡪࠦࡓࡰ࡮ࡲࠤࡘࡻࠢअ"),self.l1lll1l_thegroove+l11lll_thegroove(u"ࠢࠡࡃࡧࡨࡴࡴࠢआ"))
   return False
  try:
   l111ll_thegroove=xbmcaddon.Addon(id=self.name)
   cwd=xbmcvfs.translatePath(l111ll_thegroove.getAddonInfo(l11lll_thegroove(u"ࠨࡲࡤࡸ࡭࠭इ")))
   filepath=l11lll_thegroove(u"ࠤࡵࡩࡸࡵࡵࡳࡥࡨࡷ࠱ࡳ࡯ࡥࡷ࡯ࡩࡸ࠲ࡩࡵࡧࡰࡣࡵࡧࡲࡴࡧࡵ࠲ࡵࡿࠢई").split(l11lll_thegroove(u"ࠥ࠰ࠧउ"))
   l11ll_thegroove=cwd+os.sep+os.path.join(*filepath)
   if not os.path.isfile(l11ll_thegroove):
    raise Exception()
  except:
   self.l11l1_thegroove(l11lll_thegroove(u"ࠦࡊࡸࡲࡰࡴࡨࠤ࠸ࠨऊ"),l11lll_thegroove(u"ࠧࡌࡵ࡯ࡼ࡬ࡳࡳ࡫ࠠࡅ࡫ࡶࡴࡴࡴࡩࡣ࡫࡯ࡩ࡙ࠥ࡯࡭ࡱࠣࡗࡺࠨऋ"),self.l1lll1l_thegroove+l11lll_thegroove(u"ࠨࠠࡂࡦࡧࡳࡳࠨऌ"))
   return False
  return True
 def l1ll_thegroove(self,ll_thegroove):
  if ll_thegroove!=l11lll_thegroove(u"ࠢࡴࡧࡷࡣࡹࡵ࡫ࡦࡰࠥऍ")and ll_thegroove!=l11lll_thegroove(u"ࠣࡵࡨࡸࡤࡸࡥࡴࡷ࡯ࡸࠧऎ"):
   raise Exception()
 def l11l1_thegroove(self,s1=l11lll_thegroove(u"ࠤࠥए"),s2=l11lll_thegroove(u"ࠥࠦऐ"),l1lllll_thegroove=l11lll_thegroove(u"ࠦࠧऑ")):
  try:
   xbmcgui.Dialog().ok(self.l1lll1l_thegroove,s1,s2,l1lllll_thegroove)
  except:
   print(s1+l11lll_thegroove(u"ࠧࠦࠢऒ")+s2+l11lll_thegroove(u"ࠨࠠࠣओ")+l1lllll_thegroove)
# Created by pyminifier (https://github.com/dzhuang/pyminifier3)

