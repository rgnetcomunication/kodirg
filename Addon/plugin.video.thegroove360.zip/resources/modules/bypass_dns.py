#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
bypass_dns.py  –  plugin.video.thegroove360
Modulo di bypass DNS/rete integrato da plugin.video.torproxy/bypass.py.

Fornisce:
  - Risoluzione DNS via DoH (Cloudflare, Google, Quad9)
  - Fix SNI per connessioni dirette a IP
  - Rotazione proxy dinamici/statici
  - get_with_bypass(url, headers, timeout) → str | None
  - BypassSession: drop-in replacement di requests.Session
"""

import socket
import logging
import requests
import urllib3
import threading
import time
import ssl
from typing import Optional, Dict, List
from urllib.parse import urlparse, urlunparse
from requests.adapters import HTTPAdapter

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

log = logging.getLogger("thegroove360.bypass_dns")

# ──────────────────────────────────────────────────────────────────────
# FIX SNI: forza l'hostname corretto nell'handshake TLS anche quando
# l'URL punta a un indirizzo IP (necessario dopo risoluzione DoH).
# ──────────────────────────────────────────────────────────────────────
class _SNIAdapter(HTTPAdapter):
    def __init__(self, server_hostname: str, **kwargs):
        self._server_hostname = server_hostname
        super().__init__(**kwargs)

    def init_poolmanager(self, connections, maxsize, block=False, **kw):
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        self.poolmanager = urllib3.PoolManager(
            num_pools=connections,
            maxsize=maxsize,
            block=block,
            ssl_context=ctx,
            server_hostname=self._server_hostname,
            **kw,
        )


# ──────────────────────────────────────────────────────────────────────
# CONFIGURAZIONE
# ──────────────────────────────────────────────────────────────────────
_DOH_RESOLVERS = [
    "https://cloudflare-dns.com/dns-query",
    "https://dns.google/resolve",
    "https://dns.quad9.net/dns-query",
]

_PROXY_SOURCES: List[Dict] = [
    {
        "url": (
            "https://api.proxyscrape.com/v3/free-proxy-list/get?request=displayproxies&protocol=socks5&timeout=3000&country=all&ssl=all&anonymity=elite"
        ),
        "type": "socks5",
    },
    {
        "url": (
            "https://api.proxyscrape.com/v3/free-proxy-list/get?request=displayproxies&protocol=http&timeout=3000&country=all&ssl=all&anonymity=elite"
        ),
        "type": "http",
    },
    {
        "url": (
            "https://proxylist.geonode.com/api/proxy-list?limit=50&page=1&sort_by=lastChecked&sort_type=desc&protocols=socks5"
        ),
        "type": "socks5",
        "json": True,
    },
]

_STATIC_PROXIES: List[Dict] = [
    {"url": "http://103.152.112.162:80", "type": "http"},
    {"url": "http://185.162.231.106:80", "type": "http"},
]

_DEFAULT_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/120.0.0.0 Safari/537.36"
)

_dynamic_proxies: List[Dict] = []
_proxy_lock = threading.Lock()
_proxy_index = 0
_dns_cache: Dict[str, str] = {}
_refresh_done = False


# ──────────────────────────────────────────────────────────────────────
# 1. RESOLVER DoH
# ──────────────────────────────────────────────────────────────────────
def resolve_doh(hostname: str) -> Optional[str]:
    """Risolve un hostname via DNS-over-HTTPS. Usa la cache in-memory."""
    if hostname in _dns_cache:
        return _dns_cache[hostname]

    for resolver in _DOH_RESOLVERS:
        try:
            resp = requests.get(
                resolver,
                params={"name": hostname, "type": "A"},
                headers={"Accept": "application/dns-json"},
                timeout=4,
            )
            data = resp.json()
            for answer in data.get("Answer", []):
                if answer.get("type") == 1:          # record A → IPv4
                    ip = answer["data"]
                    _dns_cache[hostname] = ip
                    log.info("DoH: %s → %s", hostname, ip)
                    return ip
        except Exception as exc:
            log.debug("DoH resolver %s fallito: %s", resolver, exc)

    return None


# ──────────────────────────────────────────────────────────────────────
# 2. GESTIONE PROXY DINAMICI
# ──────────────────────────────────────────────────────────────────────
def _fetch_raw_proxies() -> List[Dict]:
    found: List[Dict] = []
    for src in _PROXY_SOURCES:
        try:
            resp = requests.get(src["url"], timeout=10)
            if resp.status_code != 200:
                continue
            prefix = "socks5h://" if src["type"] == "socks5" else "http://"
            if src.get("json"):
                data = resp.json()
                items = data.get("data", []) if isinstance(data, dict) else []
                for entry in items[:25]:
                    ip, port = entry.get("ip"), entry.get("port")
                    if ip and port:
                        found.append({"url": f"{prefix}{ip}:{port}", "type": src["type"]})
            else:
                for line in resp.text.splitlines()[:25]:
                    line = line.strip()
                    if ":" in line:
                        found.append({"url": f"{prefix}{line}", "type": src["type"]})
        except Exception as exc:
            log.debug("Fetch proxy fallito (%s): %s", src["url"], exc)
    return found


def _check_proxy_worker(proxy_cfg: Dict, valid_list: List[Dict]) -> None:
    try:
        proxies = {"http": proxy_cfg["url"], "https": proxy_cfg["url"]}
        r = requests.get("https://1.1.1.1", proxies=proxies, timeout=3, verify=False)
        if r.status_code == 200:
            with _proxy_lock:
                valid_list.append(proxy_cfg)
    except Exception:
        pass


def refresh_proxies() -> None:
    """Scarica e verifica proxy in background. Chiamata all'avvio (daemon)."""
    global _dynamic_proxies, _refresh_done
    log.info("Inizio refresh proxy in background…")
    raw = _fetch_raw_proxies()
    valid: List[Dict] = []
    threads = []

    for p in raw:
        t = threading.Thread(target=_check_proxy_worker, args=(p, valid))
        t.daemon = True
        t.start()
        threads.append(t)

    deadline = time.time() + 10
    for t in threads:
        left = deadline - time.time()
        if left <= 0:
            break
        t.join(timeout=left)

    with _proxy_lock:
        _dynamic_proxies = valid
        _refresh_done = True
    log.info("Refresh proxy completato: %d validati.", len(_dynamic_proxies))


def _next_proxy() -> Optional[Dict]:
    global _proxy_index
    with _proxy_lock:
        pool = _dynamic_proxies if _dynamic_proxies else _STATIC_PROXIES
        if not pool:
            return None
        proxy = pool[_proxy_index % len(pool)]
        _proxy_index += 1
        return proxy


# ──────────────────────────────────────────────────────────────────────
# 3. FUNZIONE PRINCIPALE (BYPASS A CASCATA)
# ──────────────────────────────────────────────────────────────────────
def get_with_bypass(
    url: str,
    headers: Optional[Dict] = None,
    timeout: int = 15,
) -> Optional[str]:
    """
    Esegue una GET con bypass automatico.
    Ordine dei tentativi:
      1. DoH + SNI Fix  (risolve il blocco DNS di AGCOM/ISP)
      2. Proxy dinamici verificati
      3. Proxy statici
      4. Connessione diretta
    Restituisce il testo della risposta oppure None in caso di fallimento.
    """
    req_headers = {"User-Agent": _DEFAULT_UA, "Accept": "*/*"}
    if headers:
        req_headers.update(headers)

    parsed = urlparse(url)
    hostname = parsed.hostname
    if not hostname:
        return None

    # ── Tentativo 1: DoH + SNI Fix ─────────────────────────────────
    ip = resolve_doh(hostname)
    if ip:
        try:
            netloc = f"{ip}:{parsed.port}" if parsed.port else ip
            ip_url = urlunparse(parsed._replace(netloc=netloc))
            session = requests.Session()
            session.mount(f"https://{ip}", _SNIAdapter(server_hostname=hostname))
            log.info("Bypass DoH+SNI: %s → %s", hostname, ip)
            resp = session.get(ip_url, headers=req_headers, timeout=7, verify=False)
            if resp.status_code < 400:
                return resp.text
        except Exception as exc:
            log.debug("DoH+SNI fallito: %s", exc)

    # ── Tentativo 2: Proxy (max 3 rotazioni) ───────────────────────
    for _ in range(3):
        proxy_conf = _next_proxy()
        if not proxy_conf:
            break
        try:
            proxies = {"http": proxy_conf["url"], "https": proxy_conf["url"]}
            log.info("Bypass proxy: %s", proxy_conf["url"])
            resp = requests.get(url, headers=req_headers, proxies=proxies, timeout=5)
            if resp.status_code < 400:
                return resp.text
        except Exception:
            with _proxy_lock:
                if proxy_conf in _dynamic_proxies:
                    _dynamic_proxies.remove(proxy_conf)

    # ── Tentativo 3: Connessione diretta ───────────────────────────
    try:
        log.info("Bypass diretto: %s", url)
        resp = requests.get(url, headers=req_headers, timeout=5)
        if resp.status_code < 400:
            return resp.text
    except Exception:
        pass

    return None


# ──────────────────────────────────────────────────────────────────────
# 4. MOCK RESPONSE (compatibilità con requests.Response)
# ──────────────────────────────────────────────────────────────────────
class _MockResponse:
    """
    Oggetto response minimale compatibile con l'interfaccia di
    requests.Response, costruito a partire dal testo restituito
    da get_with_bypass().
    """
    def __init__(self, text: Optional[str]):
        self.text = text or ""
        self.status_code = 200 if text else 503
        self.content = self.text.encode("utf-8", errors="replace")
        self.headers: Dict = {}
        self.url = ""

    def json(self):
        import json as _json
        return _json.loads(self.text)

    def raise_for_status(self):
        if self.status_code >= 400:
            raise requests.HTTPError(response=self)


# ──────────────────────────────────────────────────────────────────────
# 5. BYPASS SESSION (drop-in per requests.Session)
# ──────────────────────────────────────────────────────────────────────
class BypassSession:
    """
    Drop-in replacement di requests.Session che usa get_with_bypass()
    per tutte le GET, tornando a requests normale per metodi non-GET.
    I cookies vengono ignorati (non necessario per lo scraping).
    """

    def __init__(self):
        self._fallback = requests.Session()
        self.headers: Dict = {"User-Agent": _DEFAULT_UA}
        self.cookies = self._fallback.cookies

    def get(self, url: str, **kwargs) -> _MockResponse:
        merged_headers = dict(self.headers)
        merged_headers.update(kwargs.pop("headers", {}) or {})
        timeout = kwargs.pop("timeout", 15)
        # Ignoriamo kwargs restanti (stream, verify, …) — non applicabili al bypass
        text = get_with_bypass(url, headers=merged_headers, timeout=timeout)
        return _MockResponse(text)

    def post(self, url: str, **kwargs) -> requests.Response:
        return self._fallback.post(url, **kwargs)

    def close(self):
        self._fallback.close()

    # Permette l'uso come context manager
    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


# ──────────────────────────────────────────────────────────────────────
# 6. DIAGNOSTICA
# ──────────────────────────────────────────────────────────────────────
def diagnose(url: str) -> Dict:
    parsed = urlparse(url)
    hostname = parsed.hostname
    result: Dict = {"hostname": hostname, "verdict": "unknown"}

    try:
        result["system_dns"] = socket.gethostbyname(hostname)
    except Exception:
        result["system_dns"] = "BLOCKED/FAILED"

    doh_ip = resolve_doh(hostname)
    result["doh_dns"] = doh_ip if doh_ip else "FAILED"

    if result["system_dns"] == "BLOCKED/FAILED" and doh_ip:
        result["verdict"] = "DNS_BLOCK_DETECTED"
    else:
        result["verdict"] = "POSSIBLE_IP_OR_GEO_BLOCK"

    return result


# ──────────────────────────────────────────────────────────────────────
# Avvio automatico del refresh proxy (daemon thread, non blocca Kodi)
# ──────────────────────────────────────────────────────────────────────
threading.Thread(target=refresh_proxies, daemon=True).start()
