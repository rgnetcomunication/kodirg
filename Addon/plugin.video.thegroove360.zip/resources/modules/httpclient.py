#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
httpclient.py  –  plugin.video.thegroove360

Quando "Bypass DNS" è attivo nelle impostazioni, installa un patch su
socket.getaddrinfo che risolve TUTTI i domini via DoH (Cloudflare 1.1.1.1)
invece del DNS dell'ISP.

Questo copre:
  - HttpClient.get_request()       (pagine esterne, scripter)
  - requests.get() nelle pyFunction (regex inline dei channel item)
  - qualsiasi altra chiamata HTTP nell'addon

ThegrooveHttpClient rimane identico all'originale.
"""

import socket
import ssl
import http.client as _http_client
import json as _json
import logging
import random
import os

import requests
from resources.lib import kodiutils
from resources.lib.requests_doh import DNSOverHTTPSSession

log = logging.getLogger("thegroove360.httpclient")

# ──────────────────────────────────────────────────────────────────────
# SOCKET-LEVEL DNS PATCH (globale)
# ──────────────────────────────────────────────────────────────────────

_original_getaddrinfo = socket.getaddrinfo
_doh_cache = {}
_patch_active = False


def _resolve_via_doh(hostname: str):
    """
    Risolve hostname via DoH con connessione TCP diretta a 1.1.1.1.
    Non usa socket.getaddrinfo (evita loop infinito).
    """
    if hostname in _doh_cache:
        return _doh_cache[hostname]

    resolvers = [
        ("1.1.1.1", "/dns-query", "cloudflare-dns.com"),
        ("8.8.8.8", "/dns-query", "dns.google"),
        ("9.9.9.9", "/dns-query", "dns.quad9.net"),
    ]
    for ip_res, path, host_hdr in resolvers:
        try:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            conn = _http_client.HTTPSConnection(
                ip_res, port=443, timeout=4, context=ctx
            )
            conn.request(
                "GET", f"{path}?name={hostname}&type=A",
                headers={"Host": host_hdr, "Accept": "application/dns-json",
                         "User-Agent": "Mozilla/5.0"},
            )
            resp = conn.getresponse()
            if resp.status == 200:
                data = _json.loads(resp.read().decode())
                for ans in data.get("Answer", []):
                    if ans.get("type") == 1:  # record A
                        ip = ans["data"]
                        _doh_cache[hostname] = ip
                        log.info("DoH: %s → %s", hostname, ip)
                        return ip
            conn.close()
        except Exception as exc:
            log.debug("DoH resolver %s fallito: %s", ip_res, exc)
    return None


def _patched_getaddrinfo(host, port, *args, **kwargs):
    """
    Versione patchata di socket.getaddrinfo.
    Per tutti gli hostname stringa tenta la risoluzione DoH;
    se fallisce delega all'originale (fallback sicuro).
    """
    if isinstance(host, str) and host and not _is_ip(host):
        ip = _resolve_via_doh(host)
        if ip:
            log.debug("socket patch: %s → %s :%s", host, ip, port)
            return _original_getaddrinfo(ip, port, *args, **kwargs)
        # DoH fallito → usa DNS originale (meglio di niente)
        log.debug("socket patch: DoH fallito per %s, uso DNS originale", host)
    return _original_getaddrinfo(host, port, *args, **kwargs)


def _is_ip(host: str) -> bool:
    """True se host è già un indirizzo IP (IPv4 o IPv6)."""
    try:
        socket.inet_pton(socket.AF_INET, host)
        return True
    except OSError:
        pass
    try:
        socket.inet_pton(socket.AF_INET6, host)
        return True
    except OSError:
        pass
    return False


def install_dns_patch():
    """Installa il patch globale su socket.getaddrinfo (idempotente)."""
    global _patch_active
    if not _patch_active:
        socket.getaddrinfo = _patched_getaddrinfo
        _patch_active = True
        log.info("DNS socket patch GLOBALE installato")


def remove_dns_patch():
    """Ripristina socket.getaddrinfo originale."""
    global _patch_active
    if _patch_active:
        socket.getaddrinfo = _original_getaddrinfo
        _patch_active = False
        log.info("DNS socket patch rimosso")


# ──────────────────────────────────────────────────────────────────────
# Helpers impostazioni
# ──────────────────────────────────────────────────────────────────────
def _bypass_enabled() -> bool:
    try:
        return bool(kodiutils.get_setting_as_bool("use_bypass_dns"))
    except Exception:
        return False


# ──────────────────────────────────────────────────────────────────────
# INSTALLAZIONE ALL'IMPORT
# Il patch viene installato subito quando il modulo viene importato,
# se il bypass è attivo. Questo garantisce che anche le pyFunction
# inline nei regex (che usano requests.get() direttamente) vengano
# coperte, senza bisogno di modificare nulla nell'addon originale.
# ──────────────────────────────────────────────────────────────────────
if _bypass_enabled():
    install_dns_patch()


# ──────────────────────────────────────────────────────────────────────
# HttpClient — identico all'originale salvo la gestione del bypass
# ──────────────────────────────────────────────────────────────────────
class HttpClient:
    headers = {
        'pragma': 'no-cache',
        'cache-control': 'no-cache',
        'dnt': '1',
        'upgrade-insecure-requests': '1',
        'accept': '*/*',
    }

    def __init__(self):
        self.headers["user-agent"] = self.get_random_ua()

        if _bypass_enabled():
            # Il socket patch è già attivo — usiamo requests.Session normale
            self.session = requests.Session()
        elif kodiutils.get_setting_as_int("use_doh_requests"):
            dns = kodiutils.get_setting("dns_provider")
            self.session = DNSOverHTTPSSession(provider=dns)
        else:
            self.session = requests.Session()

    def get_request(self, url, **kwargs):
        if "headers" not in kwargs:
            kwargs["headers"] = {}
        request_headers = dict(self.headers)
        request_headers.update(kwargs["headers"])
        kwargs["headers"] = request_headers
        if "timeout" not in kwargs:
            kwargs["timeout"] = 15
        return self.session.get(url, **kwargs)

    def get_file(self, url, **kwargs):
        kwargs["stream"] = True
        return self.get_request(url, **kwargs)

    @staticmethod
    def get_random_ua():
        dir_path = os.path.dirname(os.path.realpath(__file__))
        with open(os.path.join(dir_path, "UA.json"), "r") as f:
            uas = _json.load(f)
        return random.choice(uas)["ua"]
